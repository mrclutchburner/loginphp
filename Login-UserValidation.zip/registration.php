<!DOCTYPE html>
<html>
<head>
	<title>Agma Form</title>
	<!--<link rel="stylesheet" type="text/css" href="style.css">-->
	<style>
body {
	background: #1690A7;
	display: flex;
	padding: 40px 40px;
	justify-content: left;
	align-items: left;
	height: 100vh;
	flex-direction: column;
}

*{
	font-family: sans-serif;
	box-sizing: border-box;
}

form {
	width: 500px;
	border: 2px solid #6e6a6a;
	padding: 30px;
	background: #ffffff52;
	border-radius: 15px;
}

h2 {
	text-align: center;
	margin-bottom: 40px;
}

input {
	display: block;
	border: 3px #686464;
	width: 95%;
	padding: 10px;
	margin: 10px auto;
	border-radius: 5px;
	background: #ffffffbd;
}
label {
	color: #625f5f;
	font-size: 18px;
	padding: 10px;
}

button {
	float: right;
	background: #555;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}
.error {
   background: #F2DEDE;
   color: #A94442;
   padding: 10px;
   width: 95%;
   border-radius: 5px;
   margin: 20px auto;
}
.success {
	background: #d4edda;
	color: #40754c;
	padding: 10px;
	width: 95%;
	border-radius: 5px;
	margin: 20px auto;
 }

h1 {
	text-align: center;
	color: #fff;
}

a {
    float: left;
    padding: 10px 15px;
    color: #444;
    border-radius: 5px;
    margin-right: 10px;
    border: none;
    text-decoration: none;
}
a.ca {
    float: left;
    padding: 10px 15px;
    color: #444;
    border-radius: 5px;
    margin-right: 10px;
    border: none;
    text-decoration: none;
}
a.ca:hover {
    text-decoration: underline;
    color: #555;
}
	</style>
</head>
<body>
     <form action="registration-check.php" method="post">
     	<h2>Register</h2>
		
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

		<?php if (isset($_GET['success'])) { ?>
     		<p class="success"><?php echo $_GET['success']; ?></p>
     	<?php } ?>

		<label>MCO Name</label>
		<?php if (isset($_GET['name'])) { ?>
			 <input type="text" 
			 		name="name"
					placeholder="Name e.g (Juan G. Dela Cruz)"
					value="<?php echo $_GET['name']; ?>"><br>
     	<?php }else{ ?>
			<input type="text"
				   name="name"
				   placeholder="Name e.g (Juan G. Dela Cruz)"><br>
		<?php }?>

		<label>Account No.</label>
		<?php if (isset($_GET['uname'])) { ?>
			 <input type="text" 
			 		name="uname"
					placeholder="Account No. e.g (00-000-0000)"
					value="<?php echo $_GET['uname']; ?>"><br>
     	<?php }else{ ?>
			<input type="text"
				   name="uname"
				   placeholder="Account No. e.g (00-000-0000)"><br>
		<?php }?>

		<label>Address</label>
		<?php if (isset($_GET['address'])) { ?>
			 <input type="text" 
			 		name="address"
					placeholder="Address e.g (Brgy. Cau-ayan Pototan, Iloilo)"
					value="<?php echo $_GET['address']; ?>"><br>
     	<?php }else{ ?>
			<input type="text"
				   name="address"
				   placeholder="Address e.g (Brgy. Cau-ayan Pototan, Iloilo)"><br>
		<?php }?>

		<label>Contact No.</label>
		<?php if (isset($_GET['contact'])) { ?>
			 <input type="text" 
			 		name="contact"
					placeholder="Contact No. e.g (09123456789)"
					value="<?php echo $_GET['Conatct']; ?>"><br>
     	<?php }else{ ?>
			<input type="text"
				   name="contact"
				   placeholder="Contact e.g (09123456789)"><br>
		<?php }?>
	
     	<button type="submit">Register</button>
     </form>
</body>
</html>